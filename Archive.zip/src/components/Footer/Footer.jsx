import React from "react";
import style from "./Footer.module.css";
import instagram from "../../assets/instagram.svg";
import whatsapp from "../../assets/whatsapp.svg";
import {TitleGlobal} from '../TitleGlobal/TitleGlobal'

export const Footer = () => {
	return (
		<div className={style.footer}>
			<TitleGlobal title="Contact" />
			<div className={style.cards}>
				<div className={style.info}>
					<div className={style.phone}>
						<p className={style.texOne}>Phone</p>
						<p className={style.texTwo}>+49 999 999 99 99</p>
					</div>
					<div className={style.socials}>
						<p className={style.texOne}>Socials</p>
						<div className={style.frame}>
							<img src={instagram} alt={instagram}></img>
							<img src={whatsapp} alt={whatsapp}></img>
						</div>
					</div>
					<div className={style.adress}>
						<p className={style.texOne}>Address</p>
						<p className={style.texTwo}>
							Linkstraße 2, 8 OG, 10 785, Berlin, Deutschland
						</p>
					</div>
					<div className={style.workingHours}>
						<p className={style.texOne}>Working Hours</p>
						<p className={style.texTwo}>24 hours a day</p>
					</div>
				</div>
			</div>
			<div className={style.map}></div>
		</div>
	);
};
