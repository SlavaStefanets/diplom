import React from "react";
import style from "./CategoryCard.module.css";

export const CategoryCard = ({ img, title }) => {
	return (
		<div>
			<img className={style.photoImg} src={img} alt="categorie"></img>
			<h6> {title}</h6>
		</div>
	);
};
