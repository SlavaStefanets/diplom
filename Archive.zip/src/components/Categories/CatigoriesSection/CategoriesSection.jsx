import React from "react";
import { TitleGlobal } from "../../TitleGlobal/TitleGlobal";
import style from "./CategoriesSection.module.css";
import {CategoriesContainer} from '../CategoriesContainer/CategoriesContainer'

export const CategoriesSection = () => {
	return (
		<div className={style.container}>
			<div className={style.headerElements}>
				<TitleGlobal title="Categories" />
				<div className={style.line}></div>
				<button>All categories </button>
			</div>
			<CategoriesContainer />
		</div>
	);
};
