import React from 'react'
import style from './TitleGlobal.module.css'

export const TitleGlobal = ({title}) => {
  return (

    <h2 className={style.titleGlobal}>
      {title}
    </h2>
  )
}
