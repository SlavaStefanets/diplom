import React from "react";
import style from './DiscountInfo.module.css'
import {Button} from '../UI/Button/Button'

export const DiscountInfo = () => {
	return (
		<div className={style.discountInfo}>
			<div>
				<h1 className={style.h1}>Amazing Discounts on Garden Products!</h1>
				<Button color={"green"} textBtn="Check out" />
			</div>
		</div>
	);
};
