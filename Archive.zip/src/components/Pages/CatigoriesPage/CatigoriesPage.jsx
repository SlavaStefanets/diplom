import React from 'react'

export const CatigoriesPage = () => {
  return (
    <div>CatigoriesPage</div>
  )
}
