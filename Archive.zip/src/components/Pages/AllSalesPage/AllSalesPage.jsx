import React from 'react'

export const AllSalesPage = () => {
  return (
    <div>AllSalesPage</div>
  )
}
