import React from 'react'

export const AllProductsPage = () => {
  return (
    <div>AllProductsPage</div>
  )
}
