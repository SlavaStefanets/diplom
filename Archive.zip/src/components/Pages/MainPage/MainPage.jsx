import React from "react";
import style from "./MainPage.module.css";
import { DiscountInfo } from "../../../components/DicsountInfo/DiscountInfo";
import { CategoriesSection } from "../../Categories/CatigoriesSection/CategoriesSection";

export const MainPage = () => {
	return (
		<div className={style.mainPage}>
			<DiscountInfo />
			<div className={style.underMainPage}>
				<CategoriesSection />
			</div>
		</div>
	);
};
