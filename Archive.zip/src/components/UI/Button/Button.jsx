import style from "./Button.module.css";

import React, { useState, useEffect } from "react";

export const Button = ({ color, func, textBtn }) => {
	const [currentColor, setCurrentColor] = useState("#FFF");
	const [textColor, setTextColor] = useState("#282828");
	const [borColor, setBorColor] = useState("#282828");

	useEffect(() => {
		switch (color) {
			case "green":
				setCurrentColor("#393");
				setBorColor("#393");
				setTextColor("#fff");
				break;
			case "black":
				setCurrentColor("#282828");
				setBorColor("#282828");
				setTextColor("#fff");
				break;
			default:
				setCurrentColor("#FFF");
				setBorColor("#282828");
				setTextColor("#282828");
				break;
		}
	}, [color]);
	return (
		<button
			className={style.btn}
			onClick={func}
			style={{
				color: textColor,
				borderColor: borColor,
				backgroundColor: currentColor,
			}}
		>
			{textBtn}
		</button>
	);
};
